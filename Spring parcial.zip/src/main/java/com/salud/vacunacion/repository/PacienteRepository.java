package com.salud.vacunacion.repository;

import com.salud.vacunacion.domain.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
    Optional<Paciente> findByIdentificacion(String identificacion);
}
