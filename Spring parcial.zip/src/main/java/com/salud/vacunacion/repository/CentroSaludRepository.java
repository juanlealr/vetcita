package com.salud.vacunacion.repository;

import com.salud.vacunacion.domain.CentroSalud;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CentroSaludRepository extends JpaRepository<CentroSalud, Long> {
}
