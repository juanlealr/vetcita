package com.salud.vacunacion.repository;

import com.salud.vacunacion.domain.Vacuna;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VacunaRepository extends JpaRepository<Vacuna, Long> {
}
