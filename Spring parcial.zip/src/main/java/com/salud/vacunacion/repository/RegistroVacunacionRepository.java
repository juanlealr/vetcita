package com.salud.vacunacion.repository;

import com.salud.vacunacion.domain.RegistroVacunacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RegistroVacunacionRepository extends JpaRepository<RegistroVacunacion, Long> {
    List<RegistroVacunacion> findByPacienteId(Long pacienteId);
}
