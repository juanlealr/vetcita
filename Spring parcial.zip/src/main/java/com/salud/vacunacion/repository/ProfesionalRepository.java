package com.salud.vacunacion.repository;

import com.salud.vacunacion.domain.Profesional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesionalRepository extends JpaRepository<Profesional, Long> {
}
