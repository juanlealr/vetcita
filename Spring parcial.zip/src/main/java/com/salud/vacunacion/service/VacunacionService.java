package com.salud.vacunacion.service;

import com.salud.vacunacion.domain.*;
import com.salud.vacunacion.dto.*;
import com.salud.vacunacion.exception.ContraindicacionException;
import com.salud.vacunacion.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VacunacionService {

    private final PacienteRepository pacienteRepository;
    private final VacunaRepository vacunaRepository;
    private final ProfesionalRepository profesionalRepository;
    private final CentroSaludRepository centroSaludRepository;
    private final RegistroVacunacionRepository registroRepository;

    @Transactional
    public RegistroVacunacionResponse registrarVacunacion(RegistroVacunacionRequest request) {
        Paciente paciente = pacienteRepository.findById(request.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));

        Vacuna vacuna = vacunaRepository.findById(request.getVacunaId())
                .orElseThrow(() -> new RuntimeException("Vacuna no encontrada"));

        Profesional profesional = profesionalRepository.findById(request.getProfesionalId())
                .orElseThrow(() -> new RuntimeException("Profesional no encontrado"));

        CentroSalud centro = centroSaludRepository.findById(request.getCentroSaludId())
                .orElseThrow(() -> new RuntimeException("Centro de salud no encontrado"));

        verificarContraindicaciones(paciente, vacuna);

        RegistroVacunacion registro = new RegistroVacunacion();
        registro.setPaciente(paciente);
        registro.setVacuna(vacuna);
        registro.setProfesional(profesional);
        registro.setCentroSalud(centro);
        registro.setDosisAdministrada(request.getDosisAdministrada());
        registro.setFechaAplicacion(request.getFechaAplicacion());

        RegistroVacunacion guardado = registroRepository.save(registro);

        return toResponse(guardado);
    }

    private void verificarContraindicaciones(Paciente paciente, Vacuna vacuna) {
        List<Contraindicacion> contraindicaciones = vacuna.getContraindicaciones();
        List<Diagnostico> diagnosticos = paciente.getDiagnosticos();

        for (Contraindicacion c : contraindicaciones) {
            if ("enfermedad_preexistente".equals(c.getTipo())) {
                boolean tieneEnfermedad = diagnosticos.stream()
                        .anyMatch(d -> "activo".equals(d.getEstado())
                                && d.getEnfermedad().getNombre().equalsIgnoreCase(c.getCriterio()));
                if (tieneEnfermedad) {
                    throw new ContraindicacionException(
                            "El paciente tiene una contraindicación activa: " + c.getDescripcion());
                }
            }
        }
    }

    public List<RegistroVacunacion> obtenerHistorialPaciente(Long pacienteId) {
        return registroRepository.findByPacienteId(pacienteId);
    }

    private RegistroVacunacionResponse toResponse(RegistroVacunacion r) {
        return new RegistroVacunacionResponse(
                r.getId(),
                r.getPaciente().getNombre(),
                r.getVacuna().getNombre(),
                r.getProfesional().getNombre(),
                r.getCentroSalud().getNombre(),
                r.getDosisAdministrada(),
                r.getFechaAplicacion()
        );
    }
}
