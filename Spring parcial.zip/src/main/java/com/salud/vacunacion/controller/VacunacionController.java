package com.salud.vacunacion.controller;

import com.salud.vacunacion.dto.RegistroVacunacionRequest;
import com.salud.vacunacion.dto.RegistroVacunacionResponse;
import com.salud.vacunacion.exception.ContraindicacionException;
import com.salud.vacunacion.service.VacunacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/registros/vacunacion")
@RequiredArgsConstructor
public class VacunacionController {

    private final VacunacionService vacunacionService;

    @PostMapping
    public ResponseEntity<?> registrarVacunacion(@RequestBody RegistroVacunacionRequest request) {
        try {
            RegistroVacunacionResponse response = vacunacionService.registrarVacunacion(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (ContraindicacionException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/paciente/{id}")
    public ResponseEntity<?> historialPaciente(@PathVariable Long id) {
        return ResponseEntity.ok(vacunacionService.obtenerHistorialPaciente(id));
    }
}
