package com.salud.vacunacion.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistroVacunacionRequest {
    private Long pacienteId;
    private Long vacunaId;
    private Long profesionalId;
    private Long centroSaludId;
    private String dosisAdministrada;
    private LocalDate fechaAplicacion;
}
