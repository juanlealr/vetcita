package com.salud.vacunacion.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistroVacunacionResponse {
    private Long id;
    private String pacienteNombre;
    private String vacunaNombre;
    private String profesionalNombre;
    private String centroSaludNombre;
    private String dosisAdministrada;
    private LocalDate fechaAplicacion;
}
