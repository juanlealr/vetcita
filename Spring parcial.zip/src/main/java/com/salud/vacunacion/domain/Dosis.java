package com.salud.vacunacion.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Dosis {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int numeroDosis;
    private int intervaloRecomendadoDias;
    private String descripcion;

    @ManyToOne
    @JoinColumn(name = "vacuna_id")
    private Vacuna vacuna;
}
