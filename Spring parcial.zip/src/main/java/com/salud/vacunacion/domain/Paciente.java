package com.salud.vacunacion.domain;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Paciente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String identificacion;

    private String nombre;
    private LocalDate fechaNacimiento;
    private String sexo;

    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL)
    private List<RegistroVacunacion> registros;

    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL)
    private List<Diagnostico> diagnosticos;
}
