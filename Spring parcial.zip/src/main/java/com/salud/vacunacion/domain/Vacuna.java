package com.salud.vacunacion.domain;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Vacuna {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String laboratorio;
    private String tipo;
    private String descripcion;

    @OneToMany(mappedBy = "vacuna", cascade = CascadeType.ALL)
    private List<Dosis> dosis;

    @OneToMany(mappedBy = "vacuna", cascade = CascadeType.ALL)
    private List<Contraindicacion> contraindicaciones;

    @ManyToMany
    @JoinTable(
        name = "vacuna_enfermedad",
        joinColumns = @JoinColumn(name = "vacuna_id"),
        inverseJoinColumns = @JoinColumn(name = "enfermedad_id")
    )
    private List<Enfermedad> enfermedadesPreviene;
}
