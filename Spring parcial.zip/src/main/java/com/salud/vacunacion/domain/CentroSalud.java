package com.salud.vacunacion.domain;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CentroSalud {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String ubicacion;
    private String nivelAtencion;

    @OneToMany(mappedBy = "centroSalud")
    private List<Profesional> profesionales;
}
