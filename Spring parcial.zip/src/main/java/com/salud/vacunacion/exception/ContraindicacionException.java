package com.salud.vacunacion.exception;

public class ContraindicacionException extends RuntimeException {
    public ContraindicacionException(String message) {
        super(message);
    }
}
